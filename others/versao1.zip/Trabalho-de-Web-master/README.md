# Trabalho-de-Web

DESENVOLVIMENTO DE SOFTWARE PARA WEB - 2019.1 (UFC - Campus Crateús)

Aplicação Web: Graphs Geek
Proposta: Rede Social
Descrição:
A Graphs Geek terá como um propósito de trazer o universo Geek (Nerd) para a vida das
pessoas. Queremos tornar este universo acessível para todos de um modo fácil e
funcional. O universo Geek é composto por diferentes veículos, como filmes,
quadrinhos, animes, séries e jogos. A Graphs Geek adota todas as franquias criadas, por
isso, teremos um acervo variado de tópicos discursivos para diferentes perfis Geek.

Desenvolvedores:
Fábio Santos e
Hartur Alcântara
